/* Public catalogue starter. Product management is enabled after Supabase setup.
   Never put a Supabase service-role key in browser code. */
const SUPABASE_URL = ""; // Add your Supabase project URL during setup.
const SUPABASE_ANON_KEY = ""; // Add your public anon/publishable key during setup.
async function loadProducts(){
  if(!SUPABASE_URL || !SUPABASE_ANON_KEY) return;
  try{
    const res=await fetch(`${SUPABASE_URL}/rest/v1/products?select=*&is_published=eq.true&order=created_at.desc`,{
      headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`}
    });
    if(!res.ok) throw new Error("Could not load catalogue");
    const products=await res.json();
    const grid=document.getElementById("product-grid");
    if(!products.length) return;
    grid.innerHTML=products.map(p=>`<article class="product-card">
      <img src="${escapeHtml(p.image_url||'')}" alt="${escapeHtml(p.name)}" loading="lazy">
      <div class="product-info"><small>${escapeHtml(p.category||'OTHER')}</small><h3>${escapeHtml(p.name)}</h3>
      <p>₹${Number(p.price||0).toLocaleString('en-IN')}</p>
      <a class="text-link" target="_blank" rel="noopener" href="https://wa.me/918131932973?text=${encodeURIComponent('Hello, I am asking about '+p.name+' (₹'+p.price+'). Is it available?')}">Ask about this product ↗</a></div></article>`).join("");
  }catch(e){console.warn(e)}
}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
loadProducts();
