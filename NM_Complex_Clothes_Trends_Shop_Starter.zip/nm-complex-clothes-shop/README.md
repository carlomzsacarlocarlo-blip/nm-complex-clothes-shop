# N.M Complex Clothes Trends Shop — starter website

A mobile-friendly product catalogue for the physical shop in Pynursla. It has no cart, checkout, payment processing or delivery workflow.

## Included
- `index.html` — public shop catalogue
- `style.css` — responsive styling
- `store.js` — public product listing integration (Supabase REST API)
- `admin.html` — admin setup placeholder, intentionally not a functioning login yet

## Shop details already included
- Name: N.M Complex Clothes Trends Shop
- Address: Pynursla Main Road, near Apex Bank, opposite Khongthaw Pharmacy, Pynursla
- WhatsApp: 8131932973
- Phone: 6033641026

## Important: administrator access is not active yet
Do not treat `admin.html` as a working secure dashboard. Before allowing product uploads, create a Supabase project and configure authentication, a private admin role, a products table, image storage, and Row Level Security. Never put a Supabase service-role key in website JavaScript.

## Deployment overview
1. Create a Supabase project at https://supabase.com/.
2. In Supabase SQL Editor, create a `products` table with fields such as `id`, `name`, `category`, `price`, `image_url`, `is_published`, `created_at`, and configure Row Level Security policies so the public can only read published products while only your authenticated admin account can insert, update, and delete.
3. Create a storage bucket for product photos and configure policies so the public can read product images and only your admin can upload/delete them.
4. Add your Supabase project URL and public anon/publishable key to `store.js`. Never use a service-role key in frontend code.
5. Build a real sign-in protected admin form before publishing admin functionality. The included `admin.html` is only a placeholder and intentionally does not accept credentials or upload products.
6. Upload the files to a GitHub repository and enable GitHub Pages in repository Settings → Pages.
7. Test the public website and admin permissions from a second browser/account before using it with customers.

## Contact links
WhatsApp link format: `https://wa.me/918131932973`
Phone link: `tel:6033641026`

The catalogue only displays products once a configured database contains published records. Prices and availability must be maintained by the shop owner.
